package com.atul.steps;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.steps.Steps;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;


@Component
public class CalculateDivideSteps extends Steps{

    @Autowired
    private ApplicationContext applicationContext;

    private IntegrationTestSession testSession;
    private int result;
    private int x;

    @Given("a variable x having value $value")
    public void givenXValue(@Named("value") int value) {
        testSession = applicationContext.getBean(IntegrationTestSession.class);
        testSession.setX(value);
    }

    @When("I divide x by $value")
    public void whenImultiplyXBy(@Named("value") int value) {
        result = testSession.divide(value);
    }

    @Then("result should be $value")
    public void thenXshouldBe(@Named("value") int value) {
        if (value != result)
            throw new RuntimeException("result is " + result + ", but should be " + value);
    }
    
    @Given("a variable x is $value")
    public void givenvalueofx(@Named("value") int value){
    	x=3;
    }
    
    @When("I add x with $value")
    public void addgivenvalue(@Named("value") int value){
    	x=x+value;
    }
    
    @Then("result would be $value")
    public void additionresult(@Named("value") int value){
    	if(x!=value)
    		throw new RuntimeException("addition test failed");
    	
    }
}

