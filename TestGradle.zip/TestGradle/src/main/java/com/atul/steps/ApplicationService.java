package com.atul.steps;

import org.springframework.stereotype.Service;


@Service
public class ApplicationService {

    public int multiply(int x, int y) {
        return x * y;
    }
    
    public int divide(int x,int y){
    	return x/y;
    }
}
