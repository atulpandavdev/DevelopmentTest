package com.atul.steps;

import static java.util.Arrays.asList;
import static org.jbehave.core.io.CodeLocations.codeLocationFromURL;
import static org.jbehave.core.reporters.Format.CONSOLE;
import static org.jbehave.core.reporters.Format.HTML;
import static org.jbehave.core.reporters.Format.TXT;
import static org.jbehave.core.reporters.Format.XML;

import java.util.ArrayList;
import java.util.List;

import org.jbehave.core.Embeddable;
import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.io.LoadFromRelativeFile.StoryFilePath;
import org.jbehave.core.io.LoadFromURL;
import org.jbehave.core.io.StoryFinder;
import org.jbehave.core.io.StoryLocation;
import org.jbehave.core.io.StoryPathResolver;
import org.jbehave.core.junit.JUnitStories;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.InjectableStepsFactory;
import org.jbehave.core.steps.spring.SpringStepsFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = { ApplicationToTest.class})
public class RemoteStory extends JUnitStories{
	
	 @Autowired
	 private ApplicationContext applicationContext;
	 
	 
	 public RemoteStory(){
		 doConfig();
	 }

	public void doConfig(){
		
		 		useConfiguration(new MostUsefulConfiguration()
		 				.useStoryLoader(new LoadFromURL())
			               .useStoryReporterBuilder(
			                       new StoryReporterBuilder()
			                           //.withCodeLocation(codeLocationFromURL("https://raw.githubusercontent.com/atulpandavdev/DevelopmentTest/master/Stories/"))
			                           //.withDefaultFormats()
			                           .withFormats(CONSOLE, TXT, HTML, XML)));
	        
	    }
		 
	 
	    public InjectableStepsFactory stepsFactory() {
	        return new SpringStepsFactory(configuration(), applicationContext);
	    }

	 /*
	@Override
    protected List<String> storyPaths() {
        // Specify story paths as remote URLs
        String codeLocation = CodeLocations.codeLocationFromURL("http://localhost:8080/static/").toExternalForm();
        return asList(codeLocation + "divide.story");      
       
    }*/
	 
	 
	
	  /*  public Configuration configuration() {
	        return super.configuration()
	               .useStoryLoader(new LoadFromURL())
	               .useStoryReporterBuilder(
	                       new StoryReporterBuilder()
	                           .withCodeLocation(codeLocationFromURL("https://raw.githubusercontent.com/atulpandavdev/DevelopmentTest/master/Stories/"))
	                           .withDefaultFormats()
	                           .withFormats(CONSOLE, TXT, HTML, XML));
	    }
*/
	 
	  public List<String> storyPaths() {
	        // Specify story paths as remote URLs
	        String codeLocation = codeLocationFromURL("https://raw.githubusercontent.com/atulpandavdev/DevelopmentTest/master/Stories/")
	                .toExternalForm();
	        	      	        
	        List<String> stories=new ArrayList<String>();
	        for(int i=0;i<2;i++){
	        	stories.add(codeLocation + "divide.story");
		        stories.add(codeLocation + "Calc_App.story");
		        
		        
	        }
	        
	        return stories;
	       //return new  StoryFinder().findPaths(codeLocation, stories, new ArrayList());
	
	    }
}
